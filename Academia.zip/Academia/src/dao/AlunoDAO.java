package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Aluno;

public class AlunoDAO {

	public ArrayList<Aluno> listAll() throws SQLException {
		ArrayList<Aluno> alunos = new ArrayList<>();
		
		Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;" + "databaseName=academia", "sa", "123456");
		
		Statement stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(
				"select * from aluno");
		while(rs.next()) {
			alunos.add(new Aluno(rs.getInt("id"),
					rs.getString("nome"),
					rs.getString("sexo"),
					rs.getString("dataNasc"),
					rs.getString("cpf"),
					rs.getString("rg"),
					rs.getDouble("peso"),
					rs.getDouble("altura"),
					rs.getString("login"),
					rs.getString("senha")));
		}
		
		rs.close();
		stmt.close();
		conn.close();		
				
		return alunos;
	}
	
	public void insert(Aluno aluno) throws Exception {
		Connection conn = DriverManager
				.getConnection("jdbc:sqlserver://localhost:1433;" + "databaseName=academia");
		
		PreparedStatement pstmt = conn
				.prepareStatement(
						"insert into aluno(nome,sexo,dataNasc,cpf,rg,peso,altura,login,senha) "
						+ "values (?,?,?,?,?,?,?,?,?)");
		
		pstmt.setString(1, aluno.getNome());
		pstmt.setString(2, aluno.getSexo());
		pstmt.setString(3, aluno.getDataNasc());
		pstmt.setString(4, aluno.getCpf());
		pstmt.setString(5, aluno.getRg());
		pstmt.setDouble(6, aluno.getPeso());
		pstmt.setDouble(7, aluno.getAltura());
		pstmt.setString(8, aluno.getLogin());
		pstmt.setString(9, aluno.getSenha());
		
		pstmt.execute();

		conn.commit();
	}
}
