package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginAcesso {

		public boolean acesso;
		
		public void Acesso(String login, String senha) throws SQLException {

		String connection = "jdbc:sqlserver://localhost:1433;" + "databaseName=academia";
			
		Connection conn = DriverManager.getConnection(connection, "sa", "123456");
		
		Statement stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery
				("select login, senha from dbo.usuario where login='" + login + "'and senha='" + senha + "'");
		
		if(rs.next()) {
			acesso = true;
		} else {
			acesso = false;
		}
		
	}
}
