package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import dao.LoginAcesso;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class InterfaceLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField campoLogin;
	private JPasswordField campoSenha;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfaceLogin frame = new InterfaceLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public InterfaceLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(120, 86, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(120, 111, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		campoLogin = new JTextField();
		campoLogin.setBounds(176, 83, 86, 20);
		contentPane.add(campoLogin);
		campoLogin.setColumns(10);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				LoginAcesso log = new LoginAcesso();
				String senhaString = String.valueOf(campoSenha.getPassword());
				
				try {
					log.Acesso(campoLogin.getText(), senhaString);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(log.acesso == true) {
					JOptionPane.showMessageDialog(null, "Acesso concedido");
				}
				else {
						JOptionPane.showMessageDialog(null, "Acesso negado");
				}
			}
			
		});
		btnEntrar.setBounds(176, 181, 89, 23);
		contentPane.add(btnEntrar);
		
		campoSenha = new JPasswordField();
		campoSenha.setBounds(176, 108, 86, 20);
		contentPane.add(campoSenha);
	}
}
